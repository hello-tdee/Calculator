TDEE CALCULATOR — GITHUB PAGES STARTER

Files:
- index.html: responsive TDEE calculator and explanatory content
- about.html: About Us page
- contact.html: Contact page (replace placeholder email)
- privacy.html: starter privacy policy (adapt to actual services)
- disclaimer.html: health/calculation disclaimer

Before publishing:
1. Replace https://YOUR-DOMAIN.example/ in index.html with your final canonical homepage URL.
2. Replace your-email@example.com in contact.html with a real monitored email address.
3. Review and personalize About, Privacy Policy, and Disclaimer. They are starter templates, not legal advice.
4. Check all pages and links on mobile and desktop.
5. Do not add AdSense code until your account is approved; follow current Google policies.

GitHub Pages steps:
1. Create a GitHub repository (for example, tdee-calculator).
2. Upload all five HTML/TXT files to the repository root.
3. Open repository Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Choose the main branch and /(root), then Save.
6. Wait for deployment and open the published URL shown in Settings > Pages.
7. Replace canonical URL and any placeholders, then commit the changes.

No backend or external API is required. Calculator inputs are processed in the browser.
